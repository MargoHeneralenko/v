﻿using System;

namespace Functions
{
    public enum SortOrder { Ascending, Descending }
    public static class DemoFunction
    {
        //TODO : Read instructions in Readme.md file and implement them.
    }
}
